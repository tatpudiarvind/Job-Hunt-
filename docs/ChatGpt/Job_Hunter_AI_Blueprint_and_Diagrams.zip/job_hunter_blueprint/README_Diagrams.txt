Job Hunter AI — Implementation Blueprint assets

Main plan:
  /mnt/data/Job_Hunter_AI_Implementation_Blueprint.docx

Standalone diagrams (PNG = easy preview, SVG = vector/editable in vector tools):
  architecture.png / architecture.svg
  workflow_discovery.png / workflow_discovery.svg
  workflow_approval.png / workflow_approval.svg

Editable diagram logic:
  Job_Hunter_AI_Diagram_Source.mmd
  Open the .mmd file in VS Code with a Mermaid preview extension, GitHub, or a Mermaid-compatible diagram editor. The plan embeds rendered copies of the diagrams; this source lets you evolve their logic.

Key assumptions in this plan:
  - Angular 22; ASP.NET Core/.NET 10 LTS.
  - SQL Server/Azure SQL + private artifact storage; a durable queue for long jobs.
  - One primary LLM provider in the MVP with a provider abstraction for later models.
  - Approved, supported browser automation only; user approval binds to a specific immutable application version.
  - Application submission and recruiter email send have separate approval records.
  - Do not invent sponsorship status, resume facts or email addresses.

Refresh framework support, job-source API capabilities and terms, and country-specific immigration evidence before production deployment.
